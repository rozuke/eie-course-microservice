

const { CourseSchema } = require('./courseModel.js');
class CourseService {

    async create(data) {
      const newCourse = await CourseSchema.create(data)
      return newCourse;
    }

    async find() {
      
      const rta = await CourseSchema.findAll();
      return rta;
    }

    async findOne(id) {
      const course = await CourseSchema.findByPk(id);
      return course;
    }

    async update(id, editCourse) {
      const user = await CourseSchema.findByPk(id);
      const rta = user.update(editCourse);
      return rta;
    }
      
    async delete(id) {
      const course = await CourseSchema.findByPk(id);
      await course.destroy();
      return {id}
    }
}

module.exports = { CourseService };