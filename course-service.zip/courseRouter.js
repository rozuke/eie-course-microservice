const { CourseService } = require('./courseService');
const service = new CourseService();

const getCourse = async (event,context) => {
    context.callbackWaitsForEmptyEventLoop = false;

    try{
        const course = await service.find();
        const response = {status: 200, body: {course}}
        return response
    }catch (error){
        console.log(error)
    }
    
}

const addCourse = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const { nombre, estado, codigo, libroId } = JSON.parse(event.body);
    const newCourse = {
        nombre,
        estado,
        codigo,
        libroId
    }
    const course = service.create(newCourse);
    return {status:200, body: {course}}
}

const updateCourse = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const { id } = event.pathParameters;
    const newCourseData =  JSON.parse(event.body);
    const course = service.update(id, newCourseData);

    return {status: 200, body: {course}}
}

const updateRecordCourse = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const { id } = event.pathParameters;
    const newCourseData =  JSON.parse(event.body);
    const course = service.updateRecord(id, newCourseData);

    return {status: 200, body: {course}}
}

const deleteCourse = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const { id } = event.pathParameters;
    const response = service.delete(id);
    return {status: 200, body: {response}}
}
module.exports = {
    getCourse,
    addCourse,
    updateCourse,
    updateRecordCourse,
    deleteCourse
}